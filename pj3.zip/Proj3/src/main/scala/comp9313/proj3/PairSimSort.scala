package comp9313.proj3

/**
 * The result of computing similarity of headline-pairs
 * @param pair_id the self-join ids
 * @param sim similarity
 */
class PairSimSort(val pair_id: (Long,Long), val sim: Double) extends Ordered[PairSimSort] with Serializable {

  // Sort by the first of pair_id and the second of pair_id
  override def compare(that: PairSimSort): Int = {
    if (this.pair_id._1 == that.pair_id._1)  {
      if (this.pair_id._2 == that.pair_id._2) {
        0
      } else if (this.pair_id._2 > that.pair_id._2) {
        1
      } else {
        -1
      }
    } else if (this.pair_id._1 > that.pair_id._1) {
      1
    } else {
      -1
    }
  }

  // Formatting result
  override def toString = pair_id +"\t"+ sim

  override def equals(t : Any) = t match {
    case that: PairSimSort =>
      this.toString.equals(that.toString)
    case _ =>
      super.equals(t)
  }

  override def hashCode = pair_id.hashCode
}
