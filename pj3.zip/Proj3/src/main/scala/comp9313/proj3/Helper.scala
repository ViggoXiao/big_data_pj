package comp9313.proj3
/**
 * the helper functions for the RDD operations
 */
object Helper {
  // Compute the Jaccard similarity
  def sim(words1: Set[String], words2: Set[String]): Double = {
    val intersection = words1.intersect(words2)
    val union = words1.union(words2)
    intersection.size.toDouble / union.size.toDouble
  }
}
