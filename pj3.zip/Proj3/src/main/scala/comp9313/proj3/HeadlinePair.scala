package comp9313.proj3

/**
 * The headline wrapper
 * @param pair_id
 * @param date_pair
 * @param words_pair
 */
case class HeadlinePair(var pair_id: (Long,Long), var date_pair: (String,String), var words_pair: (Set[String],Set[String])) extends Serializable {
  override def toString: String = {
    pair_id + " " + date_pair + " " + words_pair
  }
}
