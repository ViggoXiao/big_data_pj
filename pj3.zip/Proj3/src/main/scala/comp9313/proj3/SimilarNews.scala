package comp9313.proj3

import org.apache.spark.SparkContext

/**
 * @Description: Set similarity self-join
 */
object SimilarNews {

  // threshold of similarity
  var threshold = 0.1
  // Init the spark environment and get the arguments
  // input file path
  var headline_path = "hdfs://localhost:9000/input/tiny-data.txt"
  // output file path
  var output_path = "hdfs://localhost:9000/output/problem-3"
  // SparkContext
  var sc:SparkContext = null

  def main(args: Array[String]): Unit = {
    val sc = SparkEnv.create()
    this.sc = sc
    // Get the arguments needed
    if (args.length == 3) {
      //  the input path
      headline_path = args(0)
      //  the output path
      output_path = args(1)
      //  the threshold
      threshold = args(2).toDouble
    } else {
      // Exit with prompt
      println(
        """Usage:
          | spark-submit
          | --class comp9313.proj3.SimilarNews
          | proj3.jar
          | [input_file] [output_file] [threshold]
          | """.stripMargin)
      System.exit(-1)
    }
    // Run main program
    run()
  }

  def run(): Any = {
    // Load the records
    val headline_rdd =
      sc
        .textFile(headline_path)
        // Add the index
        .zipWithIndex()
        // Parse the record
        .map(line => {
          val fields = line._1.split(",")
          if (fields.length == 2) {
            val date = fields(0)
            val title_id = line._2
            //          println(fields.toSet.toString())
            val words = fields(1).split(" ").distinct.toSet
            (title_id,date,words)
          } else {
            null
          }
        })
        .filter(x => x != null)
        .cache()

    // Word count for tokens.
    val word_count = headline_rdd
      .flatMap(x => x._3)
      .map(x => (x,1))
      .reduceByKey((x,y) => x + y)
      // sort by frequency
      .sortBy(_._2,true)

    // Convert RDD to map
    val word_count_map = word_count.collectAsMap()
    // Broadcast the word_count_map
    val word_count_map_bc = sc.broadcast(word_count_map)
    // Broadcast the threshold
    val threshold_bc = sc.broadcast(threshold)
    // Debug for headline_rdd
    // headline_rdd.foreach(println)
    headline_rdd
      .map {
         record =>
          val raw_words = record._3.toArray
          // map the words to indexes (weight)
          val word_count_map_bc_value = word_count_map_bc.value
          val word_indexes = raw_words.map(word => word_count_map_bc_value.get(word)).zipWithIndex
          // sort index ascending
          val sorted_index = word_indexes.sortBy(_._1)
          // get the reordered words
          val sorted_words = sorted_index.map(x => raw_words(x._2))
          // get the prefix words
          val prefix_length = sorted_words.length - (sorted_words.length * threshold_bc.value).ceil.toInt + 1
          (record._1,record._2,sorted_words,prefix_length)
      }
      // Prefix filtering
      .flatMap {
        record =>
          record._3.slice(0,record._4).map {
            word => (word,record)
          }
      }
      // Group by word
      .groupBy {
        case (word,_) => word
      }
      // Generate the pairs of self-join.
      .flatMap {
        case (_,raw_records) =>
          val records = raw_records.map(x => x._2).toSeq
          records.flatMap {
            record =>
              records.map {
                record2 =>
                  // Wrapped with headlinePair
                  HeadlinePair((record._1,record2._1),(record._2,record2._2),(record._3.toSet,record2._3.toSet))
              }
          }
          .filter {
            x =>
              // filter by id1 < id2,different years
              x.pair_id._1 < x.pair_id._2 && x.date_pair._1.slice(0,4) != x.date_pair._2.slice(0,4)
          }
      }
      // Compute the similarity (Jaccard similarity)
      .mapPartitions {
        p_elems =>
          p_elems.map {
            case HeadlinePair((title_id1,title_id2),_,(words1,words2)) =>
              val similarity = Helper.sim(words1,words2)
              ((title_id1,title_id2),similarity)
          }
      }
      .map {
        case ((title_id1,title_id2),similarity) =>
          // Wrapped with PairSimSort
          new PairSimSort((title_id1,title_id2),similarity)
      }
      // Filter by threshold
      .filter(x => x.sim >= threshold_bc.value)
      // Filter the duplicates
      .distinct()
      // Sort by the first and the second
      .sortBy(x => x,ascending = true)
      // Save the result to hdfs/local
      .saveAsTextFile(output_path)
  }
}

