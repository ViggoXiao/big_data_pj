package comp9313.proj3

import org.apache.spark.{SparkConf, SparkContext}

object SparkEnv {
  /**
   * @description: Init Spark and create SparkSession
   */
  def create() = {

    val conf = new SparkConf().setAppName("Problem3").setMaster("local")
    val sc = new SparkContext(conf)
    sc
  }
}
